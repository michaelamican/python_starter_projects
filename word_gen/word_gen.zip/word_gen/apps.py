from django.apps import AppConfig


class WordGenConfig(AppConfig):
    name = 'word_gen'
