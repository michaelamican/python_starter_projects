from django.contrib import admin

# Register your models here.
# urlpatterns = [
# 	path('word_gen', views.index),
# 	path('word_gen/submit', views.index)
# 	]